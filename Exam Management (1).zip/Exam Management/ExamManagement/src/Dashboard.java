import javax.swing.*;

public class Dashboard extends JFrame {
    public Dashboard() {
        setTitle("Dashboard");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        setContentPane(new JLabel(new ImageIcon(getClass().getResource("/Images/background.png"))));
        setIconImage(new ImageIcon(getClass().getResource("/Images/icon.png")).getImage());

        JLabel title = new JLabel("Dashboard");
        title.setBounds(150, 30, 200, 30);
        add(title);

        JButton studentBtn = new JButton("Student Management");
        studentBtn.setBounds(100, 80, 200, 30);
        add(studentBtn);

        JButton examBtn = new JButton("Exam Management");
        examBtn.setBounds(100, 130, 200, 30);
        add(examBtn);

        JButton resultBtn = new JButton("Result Management");
        resultBtn.setBounds(100, 180, 200, 30);
        add(resultBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(100, 230, 200, 30);
        add(logoutBtn);

        studentBtn.addActionListener(e -> {
            dispose();
            new StudentManagementPage().setVisible(true);
        });

        examBtn.addActionListener(e -> {
            dispose();
            new AddExamPage().setVisible(true);
        });

        resultBtn.addActionListener(e -> {
            dispose();
            new ResultManagement().setVisible(true);
        });

        logoutBtn.addActionListener(e -> {
            dispose();
            new Login().setVisible(true);
        });
    }
}
