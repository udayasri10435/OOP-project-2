import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class ResultManagement extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JTextField studentIdField, examIdField, marksField;

    public ResultManagement() {
        setTitle("Result Management");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        setContentPane(new JLabel(new ImageIcon(getClass().getResource("/Images/background.png"))));
        setIconImage(new ImageIcon(getClass().getResource("/Images/icon.png")).getImage());

        JLabel title = new JLabel("Result Management");
        title.setBounds(200, 20, 200, 30);
        add(title);

        JLabel studentIdLabel = new JLabel("Student ID:");
        studentIdLabel.setBounds(50, 70, 100, 25);
        add(studentIdLabel);

        studentIdField = new JTextField();
        studentIdField.setBounds(150, 70, 150, 25);
        add(studentIdField);

        JLabel examIdLabel = new JLabel("Exam ID:");
        examIdLabel.setBounds(50, 100, 100, 25);
        add(examIdLabel);

        examIdField = new JTextField();
        examIdField.setBounds(150, 100, 150, 25);
        add(examIdField);

        JLabel marksLabel = new JLabel("Marks:");
        marksLabel.setBounds(50, 130, 100, 25);
        add(marksLabel);

        marksField = new JTextField();
        marksField.setBounds(150, 130, 150, 25);
        add(marksField);

        JButton addBtn = new JButton("Add");
        addBtn.setBounds(330, 70, 100, 25);
        add(addBtn);

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(330, 100, 100, 25);
        add(deleteBtn);

        JButton clearBtn = new JButton("Clear All");
        clearBtn.setBounds(330, 130, 100, 25);
        add(clearBtn);

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(230, 400, 100, 30);
        add(backBtn);

        model = new DefaultTableModel(new String[]{"Student ID", "Exam ID", "Marks"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 180, 480, 200);
        add(scrollPane);

        loadTable();

        addBtn.addActionListener(e -> {
            String studentId = studentIdField.getText().trim();
            String examId = examIdField.getText().trim();
            String marksText = marksField.getText().trim();

            if (!studentId.isEmpty() && !examId.isEmpty() && !marksText.isEmpty()) {
                try {
                    int marks = Integer.parseInt(marksText);
                    Result result = new Result(studentId, examId, marks);
                    DataStore.getResults().add(result);
                    model.addRow(new Object[]{studentId, examId, marks});
                    studentIdField.setText("");
                    examIdField.setText("");
                    marksField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid number for marks.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please fill all fields.");
            }
        });

        deleteBtn.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected != -1) {
                DataStore.getResults().remove(selected);
                model.removeRow(selected);
            } else {
                JOptionPane.showMessageDialog(this, "Select a row to delete.");
            }
        });

        clearBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Clear all results?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                DataStore.getResults().clear();
                model.setRowCount(0);
            }
        });

        backBtn.addActionListener(e -> {
            dispose();
            new Dashboard().setVisible(true);
        });
    }

    private void loadTable() {
        List<Result> results = DataStore.getResults();
        model.setRowCount(0);
        for (Result r : results) {
            model.addRow(new Object[]{r.getStudentId(), r.getExamId(), r.getMarks()});
        }
    }
}
