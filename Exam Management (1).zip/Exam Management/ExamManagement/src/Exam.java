public class Exam {
    private String examId;
    private String subject;
    private String date;
    private String course;

    public Exam(String examId, String subject, String date, String course) {
        this.examId = examId;
        this.subject = subject;
        this.date = date;
        this.course = course;
    }

    public String getExamId() {
        return examId;
    }

    public String getSubject() {
        return subject;
    }

    public String getDate() {
        return date;
    }

    public String getCourse() {
        return course;
    }

    @Override
    public String toString() {
        return examId + " | " + subject + " | " + date + " | " + course;
    }

}
