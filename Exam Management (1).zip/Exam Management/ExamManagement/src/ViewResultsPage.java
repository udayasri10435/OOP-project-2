import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ViewResultsPage extends JFrame {
    private DefaultListModel<String> listModel;
    private JList<String> resultList;
    private List<ExamRecord> records;

    public ViewResultsPage() {
        setTitle("View Results");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        setContentPane(new JLabel(new ImageIcon(getClass().getResource("/Images/background.png"))));
        setIconImage(new ImageIcon(getClass().getResource("/Images/icon.png")).getImage());

        JLabel title = new JLabel("Exam Results");
        title.setBounds(180, 20, 200, 30);
        add(title);

        listModel = new DefaultListModel<>();
        resultList = new JList<>(listModel);
        resultList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(resultList);
        scrollPane.setBounds(50, 70, 380, 200);
        add(scrollPane);

        JButton deleteBtn = new JButton("Delete Selected");
        deleteBtn.setBounds(50, 280, 150, 30);
        add(deleteBtn);

        JButton clearBtn = new JButton("Clear All");
        clearBtn.setBounds(220, 280, 100, 30);
        add(clearBtn);

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(180, 330, 100, 30);
        add(backBtn);

        loadRecords();

        deleteBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int index = resultList.getSelectedIndex();
                if (index != -1) {
                    listModel.remove(index);
                    records.remove(index); // remove from underlying list too
                    JOptionPane.showMessageDialog(null, "Record deleted.");
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a record to delete.");
                }
            }
        });

        clearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int confirm = JOptionPane.showConfirmDialog(null, "Clear all records?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    listModel.clear();
                    records.clear(); // clear the underlying list
                    JOptionPane.showMessageDialog(null, "All records cleared.");
                }
            }
        });

        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Dashboard().setVisible(true);
            }
        });
    }

    private void loadRecords() {
        records = DataStore.getRecords();
        listModel.clear();
        for (ExamRecord record : records) {
            listModel.addElement(record.toString());
        }
    }
}
