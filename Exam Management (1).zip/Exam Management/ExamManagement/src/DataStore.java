import java.util.ArrayList;
import java.util.List;

public class DataStore {
    private static List<ExamRecord> examRecords = new ArrayList<>();
    private static List<Student> students = new ArrayList<>();
    private static List<Exam> exams = new ArrayList<>();
    private static List<Result> results = new ArrayList<>();

    public static List<ExamRecord> getRecords() {
        return examRecords;
    }

    public static List<Student> getStudents() {
        return students;
    }

    public static List<Exam> getExams() {
        return exams;
    }

    public static List<Result> getResults() {
        return results;
    }
}
