public class UserValidation {
    public static boolean isValid(String text) {
        return text != null && !text.trim().isEmpty();
    }

    public static boolean passwordsMatch(String pw1, String pw2) {
        return pw1.equals(pw2);
    }
}
