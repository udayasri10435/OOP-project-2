import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Register extends JFrame {
    public Register() {
        setTitle("Register");
        setSize(400, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        setIconImage(new ImageIcon(getClass().getResource("/Images/icon.png")).getImage());

        JLabel title = new JLabel("Register");
        title.setBounds(150, 20, 100, 30);
        add(title);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 80, 100, 30);
        add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(150, 80, 180, 30);
        add(userText);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(50, 130, 100, 30);
        add(passLabel);

        JPasswordField passText = new JPasswordField();
        passText.setBounds(150, 130, 180, 30);
        add(passText);

        JLabel confirmLabel = new JLabel("Confirm:");
        confirmLabel.setBounds(50, 180, 100, 30);
        add(confirmLabel);

        JPasswordField confirmText = new JPasswordField();
        confirmText.setBounds(150, 180, 180, 30);
        add(confirmText);

        JButton registerBtn = new JButton("Register");
        registerBtn.setBounds(150, 240, 100, 30);
        add(registerBtn);

        JLabel message = new JLabel();
        message.setBounds(100, 290, 250, 30);
        add(message);

        JButton loginBtn = new JButton("Already have an account? Login");
        loginBtn.setBounds(80, 330, 250, 30);
        add(loginBtn);

        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = new String(passText.getPassword());
                String confirm = new String(confirmText.getPassword());

                if (!UserValidation.isValid(username) || !UserValidation.isValid(password)) {
                    message.setText("Fields cannot be empty");
                } else if (!UserValidation.passwordsMatch(password, confirm)) {
                    message.setText("Passwords do not match");
                } else {
                    User user = new User(username, password);
                    UserStore.setRegisteredUser(user);
                    message.setText("Registered successfully!");
                    JOptionPane.showMessageDialog(null, "You can now login");
                    dispose();
                    new Login().setVisible(true);
                }
            }
        });

        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login().setVisible(true);
            }
        });
    }
}
