import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame {
    public Login() {
        setTitle("Login");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        setIconImage(new ImageIcon(getClass().getResource("/Images/icon.png")).getImage());

        JLabel title = new JLabel("Login");
        title.setBounds(160, 20, 100, 30);
        add(title);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 80, 100, 30);
        add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(150, 80, 180, 30);
        add(userText);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(50, 130, 100, 30);
        add(passLabel);

        JPasswordField passText = new JPasswordField();
        passText.setBounds(150, 130, 180, 30);
        add(passText);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(150, 190, 100, 30);
        add(loginBtn);

        JLabel message = new JLabel();
        message.setBounds(100, 240, 250, 30);
        add(message);

        JButton registerBtn = new JButton("New user? Register");
        registerBtn.setBounds(110, 280, 180, 30);
        add(registerBtn);

        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = new String(passText.getPassword());

                User savedUser = UserStore.getRegisteredUser();

                if (savedUser != null &&
                        username.equals(savedUser.getUsername()) &&
                        password.equals(savedUser.getPassword())) {
                    dispose();
                    new Dashboard().setVisible(true);
                } else {
                    message.setText("Invalid credentials!");
                }
            }
        });

        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Register().setVisible(true);
            }
        });
    }
}
