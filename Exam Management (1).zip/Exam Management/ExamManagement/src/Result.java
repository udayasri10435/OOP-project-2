public class Result {
    private String studentId;
    private String examId;
    private int marks;

    public Result(String studentId, String examId, int marks) {
        this.studentId = studentId;
        this.examId = examId;
        this.marks = marks;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getExamId() {
        return examId;
    }

    public int getMarks() {
        return marks;
    }

    @Override
    public String toString() {
        return studentId + " | " + examId + " | " + marks;
    }
}
