import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class AddExamPage extends JFrame {
    private JTextField idField, subjectField, dateField, courseField;
    private JTable table;
    private DefaultTableModel model;

    public AddExamPage() {
        setTitle("Exam Management");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        setContentPane(new JLabel(new ImageIcon(getClass().getResource("/Images/background.png"))));
        setIconImage(new ImageIcon(getClass().getResource("/Images/icon.png")).getImage());

        JLabel title = new JLabel("Exam Management");
        title.setBounds(200, 20, 200, 30);
        add(title);

        JLabel idLabel = new JLabel("Exam ID:");
        idLabel.setBounds(50, 70, 100, 25);
        add(idLabel);

        idField = new JTextField();
        idField.setBounds(150, 70, 150, 25);
        add(idField);

        JLabel subjectLabel = new JLabel("Subject:");
        subjectLabel.setBounds(50, 100, 100, 25);
        add(subjectLabel);

        subjectField = new JTextField();
        subjectField.setBounds(150, 100, 150, 25);
        add(subjectField);

        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setBounds(50, 130, 100, 25);
        add(dateLabel);

        dateField = new JTextField();
        dateField.setBounds(150, 130, 150, 25);
        add(dateField);

        JLabel courseLabel = new JLabel("Course:");
        courseLabel.setBounds(50, 160, 100, 25);
        add(courseLabel);

        courseField = new JTextField();
        courseField.setBounds(150, 160, 150, 25);
        add(courseField);

        JButton addBtn = new JButton("Add");
        addBtn.setBounds(330, 70, 100, 25);
        add(addBtn);

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(330, 100, 100, 25);
        add(deleteBtn);

        JButton clearBtn = new JButton("Clear All");
        clearBtn.setBounds(330, 130, 100, 25);
        add(clearBtn);

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(230, 400, 100, 30);
        add(backBtn);

        model = new DefaultTableModel(new String[]{"Exam ID", "Subject", "Date", "Course"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 200, 480, 200);
        add(scrollPane);

        loadTable();

        addBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            String subject = subjectField.getText().trim();
            String date = dateField.getText().trim();
            String course = courseField.getText().trim();

            if (!id.isEmpty() && !subject.isEmpty() && !date.isEmpty() && !course.isEmpty()) {
                Exam exam = new Exam(id, subject, date, course);
                DataStore.getExams().add(exam);
                model.addRow(new Object[]{id, subject, date, course});
                idField.setText(""); subjectField.setText(""); dateField.setText(""); courseField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Please fill all fields.");
            }
        });

        deleteBtn.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected != -1) {
                DataStore.getExams().remove(selected);
                model.removeRow(selected);
            } else {
                JOptionPane.showMessageDialog(this, "Select a row to delete.");
            }
        });

        clearBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Clear all exams?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                DataStore.getExams().clear();
                model.setRowCount(0);
            }
        });

        backBtn.addActionListener(e -> {
            dispose();
            new Dashboard().setVisible(true);
        });
    }

    private void loadTable() {
        List<Exam> exams = DataStore.getExams();
        model.setRowCount(0);
        for (Exam e : exams) {
            model.addRow(new Object[]{e.getExamId(), e.getSubject(), e.getDate(), e.getCourse()});
        }
    }
}