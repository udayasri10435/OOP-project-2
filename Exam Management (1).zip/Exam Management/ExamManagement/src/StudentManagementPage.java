import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class StudentManagementPage extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JTextField idField, nameField, courseField;

    public StudentManagementPage() {
        setTitle("Student Management");
        setSize(600, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);

        setContentPane(new JLabel(new ImageIcon(getClass().getResource("/Images/background.png"))));
        setIconImage(new ImageIcon(getClass().getResource("/Images/icon.png")).getImage());

        JLabel title = new JLabel("Student Management");
        title.setBounds(200, 20, 200, 30);
        add(title);

        JLabel idLabel = new JLabel("Student ID:");
        idLabel.setBounds(50, 70, 100, 25);
        add(idLabel);

        idField = new JTextField();
        idField.setBounds(150, 70, 150, 25);
        add(idField);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 100, 100, 25);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(150, 100, 150, 25);
        add(nameField);

        JLabel courseLabel = new JLabel("Course:");
        courseLabel.setBounds(50, 130, 100, 25);
        add(courseLabel);

        courseField = new JTextField();
        courseField.setBounds(150, 130, 150, 25);
        add(courseField);

        JButton addBtn = new JButton("Add");
        addBtn.setBounds(330, 70, 100, 25);
        add(addBtn);

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(330, 100, 100, 25);
        add(deleteBtn);

        JButton clearBtn = new JButton("Clear All");
        clearBtn.setBounds(330, 130, 100, 25);
        add(clearBtn);

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(230, 400, 100, 30);
        add(backBtn);

        model = new DefaultTableModel(new String[]{"ID", "Name", "Course"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 180, 480, 200);
        add(scrollPane);

        loadTable();

        addBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            String name = nameField.getText().trim();
            String course = courseField.getText().trim();

            if (!id.isEmpty() && !name.isEmpty() && !course.isEmpty()) {
                Student student = new Student(id, name, course);
                DataStore.getStudents().add(student);
                model.addRow(new Object[]{id, name, course});
                idField.setText(""); nameField.setText(""); courseField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Please fill all fields.");
            }
        });

        deleteBtn.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected != -1) {
                DataStore.getStudents().remove(selected);
                model.removeRow(selected);
            } else {
                JOptionPane.showMessageDialog(this, "Select a row to delete.");
            }
        });

        clearBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Clear all students?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                DataStore.getStudents().clear();
                model.setRowCount(0);
            }
        });

        backBtn.addActionListener(e -> {
            dispose();
            new Dashboard().setVisible(true);
        });
    }

    private void loadTable() {
        List<Student> students = DataStore.getStudents();
        model.setRowCount(0);
        for (Student s : students) {
            model.addRow(new Object[]{s.getId(), s.getName(), s.getCourse()});
        }
    }
}
